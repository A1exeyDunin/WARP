<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

use yii\web\UploadedFile;
use app\models\categories\RpCategory;
use app\models\categories\Historical;
use app\models\categories\Rest_with_tents;
use app\models\categories\Swim;
use app\models\categories\Rest_base;
use app\models\categories\Cycling_trip;
use app\models\categories\Unusual_places;
use app\models\SinglePlace;
use app\models\AddPlace;


class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /*-------------------------------------------------------------------------------------------------------------------- */
    public function actionCategories()
    {
        $historical = RpCategory::getHistorical();
        $tents = RpCategory::getRest_with_tents();
        $swim = RpCategory::getSwim();
        $base = RpCategory::getRest_base();
        $cycle = RpCategory::getCycling_trip();
        $unusual = RpCategory::getUnusual_places();
        return $this->render('categories',
            ['historical' => $historical, 'tents' => $tents, 'swim' => $swim, 'base' => $base, 'cycle' => $cycle, 'unusual' => $unusual]);
    }

//>>>>>>>------------ список мест в конкретной категории ---------->>>>>>>>>>>>
//------------------------------1----------------------------------------------
    public function action1_historical()
    {
        $historical = Historical::getAll();
        return $this->render('1_historical', ['historical' => $historical]);
    }

//------------------------------2----------------------------------------------
    public function action2_rest_with_tents()
    {
        $tents = Rest_with_tents::getAll();
        return $this->render('2_rest_with_tents', ['tents' => $tents]);
    }

//------------------------------3----------------------------------------------
    public function action3_swim()
    {
        $swim = Swim::getAll();
        return $this->render('3_swim', ['swim' => $swim]);
    }

//------------------------------4----------------------------------------------
    public function action4_rest_base()
    {
        $base = Rest_base::getAll();
        return $this->render('4_rest_base', ['base' => $base]);
    }

//------------------------------5----------------------------------------------
    public function action5_cycling_trip()
    {
        $cycle = Cycling_trip::getAll();
        return $this->render('5_cycling_trip', ['cycle' => $cycle]);
    }

//------------------------------6----------------------------------------------
    public function action6_unusual_places()
    {
        $unusual = Unusual_places::getAll();
        return $this->render('6_unusual_places', ['unusual' => $unusual]);
    }

//--------------------отдельная статья------------------------>>>>>>>>>>>>>>>>>
    public function actionSingle_place($id)
    {
        $single = SinglePlace::getOne($id);
        return $this->render('single_place', ['single' => $single]);
    }

//---------------------добавить место--------------------------->>>>>>>>>>>>>>>
    public function actionAdd_place()
    {
        $model = new AddPlace();

        if ($model->load(Yii::$app->request->post())) {
            $photoName = $model->title;
            $model->file = UploadedFile::getInstance($model, 'file');
            $model->file->saveAs('uploads/' . $photoName . '_' . $model->file->baseName . '.' . $model->file->extension);
            $model->photo = 'uploads/' . $photoName . '_' . $model->file->baseName . '.' . $model->file->extension;

            $model->save();
            $this->redirect(['categories']);
        }

        return $this->render('add_place', ['model' => $model,]);
    }
}
