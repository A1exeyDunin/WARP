<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Addplace */
/* @var $form ActiveForm */
?>
<div class="add_place">
    <div class="row">
        <div class="col-lg-6">
            <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

            <?= $form->field($model, 'title') ?>
            <?= $form->field($model, 'content')->textarea(['rows' => 6]) ?>
            <?= $form->field($model, 'way')->textarea(['rows' => 6]) ?>
            <?= $form->field($model, 'file')->fileInput(); ?>
            <?= $form->field($model, 'category_id')->dropDownList(
                [
                    1 => 'Историко-культурные',
                    2 => 'Отдых с палатками',
                    3 => 'Купание',
                    4 => 'Базы отдыха',
                    5 => 'Велотуры',
                    6 => 'Необычные места',
                ],
                ['prompt' => '- Выберите категорию -']) ?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div><!-- add_place -->
