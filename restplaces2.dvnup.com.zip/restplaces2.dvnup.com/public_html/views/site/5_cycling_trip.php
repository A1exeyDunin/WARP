<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Вело-туры';
$this->params['breadcrumbs'][] = $this->title;
?>

<?php foreach ($cycle as $item): ?>
    <p>
    <li>
        <a href="/public_html/index.php/site/single_place/<?= $item->id ?>">
            <?= $item->title ?> </a>
    </li>
    </p>
<?php endforeach; ?>