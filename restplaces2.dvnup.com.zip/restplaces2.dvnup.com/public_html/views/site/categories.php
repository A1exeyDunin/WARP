<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Категории';
$this->params['breadcrumbs'][] = $this->title;
?>

<?php foreach ($historical as $item): ?>
    <a href="/public_html/index.php/site/1_historical/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>

<?php foreach ($tents as $item): ?>
    <a href="/public_html/index.php/site/2_rest_with_tents/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>

<?php foreach ($swim as $item): ?>
    <a href="/public_html/index.php/site/3_swim/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>

<?php foreach ($base as $item): ?>
    <a href="/public_html/index.php/site/4_rest_base/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>

<?php foreach ($cycle as $item): ?>
    <a href="/public_html/index.php/site/5_cycling_trip/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>

<?php foreach ($unusual as $item): ?>
    <a href="/public_html/index.php/site/6_unusual_places/<?= $item->id ?>"> <?= $item->title ?> </a></br>
<?php endforeach; ?>
