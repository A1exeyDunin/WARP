<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Отдых с палатками';
$this->params['breadcrumbs'][] = $this->title;
?>

<?php foreach ($tents as $item): ?>
    <p>
    <li>
        <a href="/public_html/index.php/site/single_place/<?= $item->id ?>">
            <?= $item->title ?> </a>
    </li>
    </p>
<?php endforeach; ?>