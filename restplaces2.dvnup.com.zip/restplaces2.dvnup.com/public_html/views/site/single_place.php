<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = '→';
$this->params['breadcrumbs'][] = $this->title;
?>


<h1><?= $single->title ?></h1>
<br>
<h2>Описание</h2><hr>
<p><?= $single->content ?></p>
<br>
<h2>Как сюда добраться</h2><hr>
<p><?= $single->way ?></p>
<br>
<h2>Фотографии</h2><hr>
<p><img src="/public_html/<?= $single->photo ?>"></p>
<br>
<h2>Отзывы</h2><hr>
<p></p>

