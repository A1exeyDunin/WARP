function initializeMaps() {
          var latlng = new google.maps.LatLng(51.4920, 31.3010);
          var myOptions = {
              zoom: 15,
              center: latlng,
              disableDefaultUI: true,
              scrollwheel: true,
              mapTypeId: google.maps.MapTypeId.ROADMAP,
          };
          var map = new google.maps.Map(document.getElementById('map'),myOptions);
          var mc = new MarkerClusterer(map)
          var marker, i;
            for (i = 0; i < data.markers.length; i++) {  
                marker = new google.maps.Marker({
                  position: new google.maps.LatLng(data.markers[i].lat, data.markers[i].lng),
                  map: map,
                  title: data.markers[i].name
                });
                mc.addMarker(marker);
            }
        }