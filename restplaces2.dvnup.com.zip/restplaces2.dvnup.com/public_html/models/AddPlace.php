<?php

namespace app\models;

use Yii;



/**
 * This is the model class for table "rp_page".
 *
 * @property integer $id
 * @property string $title
 * @property string $content
 * @property string $way
 * @property string $created
 * @property integer $status
 * @property integer $category_id
 * @property string $photo
 */
class AddPlace extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */

    public $file;

    public static function tableName()
    {
        return 'rp_page';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'content', 'way', 'category_id'], 'required'],
            [['content', 'way'], 'string'],
            [['file'], 'file'],
            [['created'], 'safe'],
            [['category_id'], 'integer'],
            [['title', 'photo'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Название места',
            'content' => 'Расскажите об этом месте',
            'way' => 'Как сюда добраться ?',
            'file' => 'Добавьте фото',
            'category_id' => 'Выберете категорию',
        ];
    }


}
