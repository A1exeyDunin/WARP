<?php

namespace app\models;
use yii\db\ActiveRecord;


class SinglePlace extends ActiveRecord
{
    public static function tableName()
    {
        return 'rp_page';
    }

    public static function getOne($id)
    {
        $data = self::find()->where(['id'=>$id])->one();
        return $data;
    }


}

