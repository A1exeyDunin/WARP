<?php

namespace app\models\categories;

use Yii;

/**
 * This is the model class for table "rp_category".
 *
 * @property integer $id
 * @property string $title
 */
class RpCategory extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'rp_category';
    }

    /**
     * @inheritdoc
     */

    public static function getAll()
    {
        $data = self::find()->all();

        return $data;
    }
//-----------категории------------->>>>
    public static function getHistorical()
    {
        $data = self::find()->where(['id'=>1])->all();
        return $data;
    }
    public static function getRest_with_tents()
    {
        $data = self::find()->where(['id'=>2])->all();
        return $data;
    }

    public static function getSwim()
    {
        $data = self::find()->where(['id'=>3])->all();
        return $data;
    }

    public static function getRest_base()
    {
        $data = self::find()->where(['id'=>4])->all();
        return $data;
    }

    public static function getCycling_trip()
    {
        $data = self::find()->where(['id'=>5])->all();
        return $data;
    }

    public static function getUnusual_places()
    {
        $data = self::find()->where(['id'=>6])->all();
        return $data;
    }
//------------------------------------------------------------
    public function rules()
    {
        return [
            [['title'], 'required'],
            [['title'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
        ];
    }
}
