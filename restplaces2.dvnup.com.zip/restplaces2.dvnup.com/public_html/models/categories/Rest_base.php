<?php
namespace app\models\categories;

use yii\db\ActiveRecord;

class Rest_base extends ActiveRecord
{
    public static function tableName()
    {
        return 'rp_page';
    }

    public static function getAll()
    {
        $data = self::find()->where(['category_id' => 4])->all();
        return $data;
    }
}