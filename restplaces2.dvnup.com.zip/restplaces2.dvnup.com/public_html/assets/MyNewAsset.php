<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\assets;

use yii\web\AssetBundle;

/**
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class MyNewAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/site.css',
        'css/modern-business.css'
    ];
    /*public $jsOptions = [
    'async' => 'async',
    ];*/
    public $js = [
        'js/map-options.js',
        'js/jquery.js',
        'js/markerclusterer.js',
        'js/data.json',
        '//maps.googleapis.com/maps/api/js?key=AIzaSyCLwUZ4lDqeLI2s_ea_kpKmiJaQea8Zz8s&callback=initMap'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
    ];
}

//AIzaSyCLwUZ4lDqeLI2s_ea_kpKmiJaQea8Zz8s - browser API key
//AIzaSyB8vB45Ynq-yeNyRhAd_UF5Lc0yqqnka6U - web server API key (tomcat, node.js)