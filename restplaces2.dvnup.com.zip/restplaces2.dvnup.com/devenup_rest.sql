-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 25 2016 г., 16:34
-- Версия сервера: 5.6.26
-- Версия PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `devenup_rest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `rp_category`
--

CREATE TABLE IF NOT EXISTS `rp_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `rp_category`
--

INSERT INTO `rp_category` (`id`, `title`) VALUES
(1, 'Историко-культурные'),
(2, 'Отдых с палатками'),
(3, 'Купание'),
(4, 'Базы отдыха'),
(5, 'Вело-туры'),
(6, 'Необычные места');

-- --------------------------------------------------------

--
-- Структура таблицы `rp_comments`
--

CREATE TABLE IF NOT EXISTS `rp_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `page_id` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `guest` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `rp_comments`
--

INSERT INTO `rp_comments` (`id`, `content`, `page_id`, `created`, `user_id`, `guest`) VALUES
(1, '333333333333333', 1, '2016-03-23 00:00:00', 1, 1),
(2, '1111111111111111', 2, '2016-03-23 14:06:22', 2, 0),
(3, '666666666666666', 1, '2016-03-23 14:34:40', 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `rp_page`
--

CREATE TABLE IF NOT EXISTS `rp_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `way` text NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Дамп данных таблицы `rp_page`
--

INSERT INTO `rp_page` (`id`, `title`, `content`, `way`, `created`, `status`, `category_id`, `photo`) VALUES
(1, 'болдиная гора', 'text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext text_rext ', 'move -> to -> kolokolnya', '2016-03-16 14:47:00', 0, 1, ''),
(2, 'вал', 'qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty qwerty ', '', '2016-03-19 00:00:00', 0, 1, ''),
(3, 'берег десны', 'пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви пывдтаоатаыви ', '', '2016-03-21 11:49:00', 0, 2, ''),
(4, 'снов', 'егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи егегитктиыи ', '', '2016-03-21 11:55:40', 0, 2, ''),
(5, 'Земик', 'воду лучше не пить', '', '2016-03-22 09:00:00', 0, 3, ''),
(6, 'золотой пляж', 'много людей', '', '2016-03-22 15:38:00', 0, 3, ''),
(7, 'ладинка', 'летом норм', '', '2016-03-22 03:00:25', 0, 4, ''),
(8, 'база на голубых озерах', 'наверное дорого', '', '2016-03-22 06:32:00', 0, 4, ''),
(9, 'еловщина', 'по горкам поездить', '', '2016-03-22 09:16:15', 0, 5, ''),
(10, 'пролетарский гай', 'там когда то были трамплины', '', '2016-03-22 11:20:31', 0, 5, ''),
(11, 'шерстянка ночью', 'не подсвечивай дорогу телефоном', '', '2016-03-22 15:18:00', 0, 6, ''),
(12, 'поселок', 'тоже лучше ночью не ходить', '', '2016-03-22 11:17:12', 0, 6, ''),
(24, 'десна мост', 'арарармтфмуафмишимшимшимшгы', '', '2016-03-23 09:19:54', 0, 3, 'uploads/250px-Desna_River_in_Chernihiv.jpg'),
(25, '123', '123', '', '2016-03-23 09:46:13', 0, 2, 'uploads/123.jpg'),
(26, 'iiiiiiiiiiiiiiiiii', 'ooooooooooooooooooo', '', '2016-03-23 11:50:20', 0, 5, 'uploads/iiiiiiiiiiiiiiiiii.jpg'),
(27, 'качановка', 'поместье и сад большой', 'на автобусе', '2016-03-24 14:58:31', 0, 1, 'uploads/качановка.jpg'),
(28, 'болдиная горка', '2 горы на велике поездить', 'на велике', '2016-03-24 15:00:06', 0, 5, 'uploads/болдиная горка.jpg'),
(29, 'new', 'new', 'wen', '2016-03-24 16:15:23', 0, 1, 'uploads/new.jpg'),
(30, 'test', 'ryryefhasFHsd;lhvzdslvzdsv', 'sdzbgzsbgzsd', '2016-03-24 16:22:07', 0, 6, 'uploads/test.jpg'),
(31, 'zz', 'zzzz', 'zzzzzz', '2016-03-25 08:41:39', 0, 6, 'uploads/250px-Desna_River_in_Chernihiv_zz.jpg'),
(32, 'stroyka', 'slomat'' 4toto', 'nogami', '2016-03-25 08:46:38', 0, 4, 'uploads/stroyka_spuskotvala.jpg'),
(33, 'fdffdfd', 'vcdsva', 'vcvz', '2016-03-25 10:21:56', 0, 2, 'uploads/250px-Desna_River_in_Chernihiv_fdffdfd.jpg'),
(34, 'yyyyyyyy', 'gfdbdfbdfb', 'zbc xvxb vxcbzfdb', '2016-03-25 10:40:26', 0, 4, 'uploads/qwqwqw_yyyyyyyy.jpg'),
(35, 'kkkkk', 'vfgf', 'bdsfb', '2016-03-25 10:43:04', 0, 2, 'uploads/qwqwqw_kkkkk.jpg'),
(36, 'новое место', 'аоывфоавыоп', 'овшщутфсщшыфтм вфтмф', '2016-03-25 10:56:24', 0, 5, 'uploads/fsdfsdfdff_новое место.jpg'),
(45, 'oooo', 'ouykk', 'umcm', '2016-03-25 15:02:41', 0, 2, 'uploads/qwqwqw_oooo.jpg'),
(46, 'xxx', 'xxx', 'xxx', '2016-03-25 15:16:45', 0, 6, 'uploads/xxx_250px-Desna_River_in_Chernihiv.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `rp_users`
--

CREATE TABLE IF NOT EXISTS `rp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ban` tinyint(1) NOT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
